# Monitoring and Alerting

## Tools

- Prometheus + Grafana
- Zabbix
- Netdata

## Setup

- Install monitoring agents
- Configure dashboards
- Set up alerts for critical events

# VPN and Authentication

## VPN

- Set up WireGuard for remote access
- Configure client connections

## Authentication

- Use strong passwords
- Enable two-factor authentication where possible
- Regularly audit access logs
